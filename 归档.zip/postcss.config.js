module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // 添加这一行
    autoprefixer: {},
  },
};