export function translateStrToNumber(v: string, baseUnit = 100000000, suffix = 2) {
  return Number((Number(String(v).replaceAll('%', '').replaceAll(",", ''))/baseUnit).toFixed(suffix));
}