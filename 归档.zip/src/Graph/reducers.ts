import type { IAction, IState } from './types';

export const initState: IState = {
  netCashFlowVersusRatinedProfitsData: {
    xAxisData: [],
    netCashFlowData: [],
    retainedProfitsData: [],
    rateData: [],
  },
  sellGoodsOrServiceCashFlowVersusOperatingReceiptData: {
    xAxisData: [],
    sellGoodsOrServiceCashFlowData: [],
    operatingReceiptData: [],
    rateData: [],
  },
  stocks: [],
  activedStockCode: '',
};

export function reducers(prevState: IState, action: IAction) {
  const { type, payload } = action;
  switch (type) {
    case 'setActivedStockCode':
      return { ...prevState, activedStockCode: payload };
    case 'setStocks':
      return { ...prevState, stocks: payload };
    case 'setNetCashFlowVersusRatinedProfitsData':
      return { ...prevState, netCashFlowVersusRatinedProfitsData: payload };
    case 'setSellGoodsOrServiceCashFlowVersusOperatingReceiptData':
      return { ...prevState, sellGoodsOrServiceCashFlowVersusOperatingReceiptData: payload };
    default:
      return prevState;
  }
}